package com.example.projectappstephenson;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class AddWeightActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 100;

    EditText weightInput, goalInput;
    Button saveBtn, btnCancel;
    DatabaseHelper db;
    String currentUsername;

    // Track variables to execute SMS sending after a permission prompt response
    private boolean pendingGoalCelebration = false;
    private double savedCurrentWeight = 0.0;
    private double savedGoalWeight = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        currentUsername = getIntent().getStringExtra("CURRENT_USER");

        weightInput = findViewById(R.id.etWeight);
        goalInput = findViewById(R.id.etGoal);
        saveBtn = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);

        db = new DatabaseHelper(this);

        Cursor cursor = db.getLatestWeight(currentUsername);
        if (cursor != null && cursor.moveToFirst()) {
            double lastGoal = cursor.getDouble(cursor.getColumnIndexOrThrow("goal_weight"));
            goalInput.setHint(String.format("Current Goal: %.1f (Optional)", lastGoal));
            cursor.close();
        }

        saveBtn.setOnClickListener(v -> {
            String weightStr = weightInput.getText().toString().trim();
            String goalStr = goalInput.getText().toString().trim();

            if (weightStr.isEmpty()) {
                Toast.makeText(this, "Please enter your current weight", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                savedCurrentWeight = Double.parseDouble(weightStr);
                savedGoalWeight = savedCurrentWeight;

                Cursor c = db.getLatestWeight(currentUsername);
                if (c != null && c.moveToFirst()) {
                    savedGoalWeight = goalStr.isEmpty() ? c.getDouble(c.getColumnIndexOrThrow("goal_weight")) : Double.parseDouble(goalStr);
                    c.close();
                } else {
                    if (goalStr.isEmpty()) {
                        Toast.makeText(this, "Please specify a goal weight for your first log", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    savedGoalWeight = Double.parseDouble(goalStr);
                }

                // Check oldest log to determine baseline direction (loss vs gain)
                double baselineWeight = savedCurrentWeight;
                Cursor oldest = db.getAllWeights(currentUsername);
                if (oldest != null && oldest.moveToLast()) {
                    baselineWeight = oldest.getDouble(oldest.getColumnIndexOrThrow("current_weight"));
                    oldest.close();
                }

                // Save data to Database
                db.insertWeight(savedCurrentWeight, savedGoalWeight, currentUsername);

                // Determine if target is reached or surpassed
                boolean goalAchieved = false;
                if (baselineWeight >= savedGoalWeight) {
                    if (savedCurrentWeight <= savedGoalWeight) goalAchieved = true;
                } else {
                    if (savedCurrentWeight >= savedGoalWeight) goalAchieved = true;
                }

                if (goalAchieved) {
                    pendingGoalCelebration = true;
                    checkSmsPermissionAndSend();
                } else {
                    Toast.makeText(this, "Weights stored successfully", Toast.LENGTH_SHORT).show();
                    finish();
                }

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Please enter valid numeric data", Toast.LENGTH_SHORT).show();
            }
        });

        btnCancel.setOnClickListener(v -> finish());
    }

    /**
     * Checks if the app has the SEND_SMS permission.
     * If granted, it fires the text immediately. If not, it requests permission dynamically.
     */
    private void checkSmsPermissionAndSend() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            // Outcome A: Permission is already granted
            sendWeightGoalSms();
        } else {
            // Prompt the user for permission dynamically
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Outcome A: The user clicked "Allow"
                Toast.makeText(this, "SMS Permission Granted!", Toast.LENGTH_SHORT).show();
                if (pendingGoalCelebration) {
                    sendWeightGoalSms();
                }
            } else {
                // Outcome B: The user clicked "Deny". App continues functioning smoothly without the feature.
                Toast.makeText(this, "SMS Permission Denied. Continuing without text alerts.", Toast.LENGTH_LONG).show();
                showFallbackMessage();
            }
        }
    }

    /**
     * Sends SMS notification message
     */
    private void sendWeightGoalSms() {
        try {
            String smsMessage = "🎉 Weight Tracker Alert: Congratulations " + currentUsername +
                    "! You have officially reached your goal weight target of " + savedGoalWeight + " lbs!";

            String emulatorPhoneNumber = "5555215554";


            SmsManager smsManager;
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                smsManager = this.getSystemService(SmsManager.class);
            } else {
                smsManager = SmsManager.getDefault();
            }

            if (smsManager != null) {
                smsManager.sendTextMessage(emulatorPhoneNumber, null, smsMessage, null, null);
                Toast.makeText(this, "Success: Goal Alert SMS sent to " + emulatorPhoneNumber, Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Error: SmsManager initialization failed.", Toast.LENGTH_SHORT).show();
            }
            finish();
        } catch (Exception e) {
            Toast.makeText(this, "SMS dispatch failed. Saving metrics without alert.", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    /**
     * Fallback mechanism if the user completely denies SMS permissions
     */
    private void showFallbackMessage() {
        new AlertDialog.Builder(this)
                .setTitle("Goal Met!")
                .setMessage("Fantastic job! You've achieved your target weight!")
                .setPositiveButton("Done", (dialog, which) -> {
                    dialog.dismiss();
                    finish();
                })
                .setCancelable(false)
                .show();
    }
}