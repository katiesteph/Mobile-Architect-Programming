package com.example.projectappstephenson;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class DashboardActivity extends AppCompatActivity {

    TextView tvCurrent, tvGoal, tvDifference;
    Button btnLog;
    DatabaseHelper db;

    RecyclerView rvHistory;
    WeightAdapter adapter;
    String currentUsername; // Stores the active user context

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        currentUsername = getIntent().getStringExtra("CURRENT_USER");

        tvCurrent = findViewById(R.id.tvCurrentWeightDisplay);
        tvGoal = findViewById(R.id.tvGoalWeightDisplay);
        tvDifference = findViewById(R.id.tvDifferenceDisplay);
        btnLog = findViewById(R.id.btnGoToAddWeight); // Kept only the log button

        rvHistory = findViewById(R.id.rvWeightHistory);
        rvHistory.setLayoutManager(new LinearLayoutManager(this));

        db = new DatabaseHelper(this);

        // Simple single click listener to move to adding weights
        btnLog.setOnClickListener(v -> {
            Intent intent = new Intent(this, AddWeightActivity.class);
            intent.putExtra("CURRENT_USER", currentUsername);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadDashboardMetrics();

        // Pass username context to fetch only this user's records
        Cursor cursor = db.getAllWeights(currentUsername);
        if (cursor != null) {
            adapter = new WeightAdapter(this, cursor);
            rvHistory.setAdapter(adapter);
        }
    }

    private void loadDashboardMetrics() {
        Cursor cursor = db.getLatestWeight(currentUsername);
        if (cursor != null && cursor.moveToFirst()) {
            double current = cursor.getDouble(cursor.getColumnIndexOrThrow("current_weight"));
            double goal = cursor.getDouble(cursor.getColumnIndexOrThrow("goal_weight"));

            double baseline = current;
            Cursor oldest = db.getAllWeights(currentUsername);
            if (oldest != null && oldest.moveToLast()) {
                baseline = oldest.getDouble(oldest.getColumnIndexOrThrow("current_weight"));
                oldest.close();
            }

            tvCurrent.setText(String.format("Current Weight: %.1f lbs", current));
            tvGoal.setText(String.format("Goal Weight: %.1f lbs", goal));

            if (baseline >= goal) {
                if (current <= goal) {
                    double extra = goal - current;
                    tvDifference.setText(String.format("Goal Achieved! (Bonus: %.1f lbs)", extra));
                } else {
                    double diff = current - goal;
                    tvDifference.setText(String.format("Distance to Goal: %.1f lbs left", diff));
                }
            } else {
                if (current >= goal) {
                    double extra = current - goal;
                    tvDifference.setText(String.format("Goal Achieved! (Bonus: %.1f lbs)", extra));
                } else {
                    double diff = goal - current;
                    tvDifference.setText(String.format("Distance to Goal: %.1f lbs left", diff));
                }
            }
            cursor.close();
        } else {
            tvCurrent.setText("Current Weight: No data logged");
            tvGoal.setText("Goal Weight: No data logged");
            tvDifference.setText("Distance to Goal: --");
        }
    }

    private static class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {
        private final Context context;
        private final Cursor cursor;

        public WeightAdapter(Context context, Cursor cursor) {
            this.context = context;
            this.cursor = cursor;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(context).inflate(R.layout.weight_item, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            if (cursor.moveToPosition(position)) {
                String date = cursor.getString(cursor.getColumnIndexOrThrow("logged_at"));
                double weight = cursor.getDouble(cursor.getColumnIndexOrThrow("current_weight"));

                if (date != null && date.length() > 16) {
                    date = date.substring(0, 16);
                }

                holder.tvDate.setText(date);
                holder.tvWeight.setText(String.format("%.1f lbs", weight));
            }
        }

        @Override
        public int getItemCount() {
            return cursor != null ? cursor.getCount() : 0;
        }

        public static class ViewHolder extends RecyclerView.ViewHolder {
            TextView tvDate, tvWeight;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);
                tvDate = itemView.findViewById(R.id.tvItemDate);
                tvWeight = itemView.findViewById(R.id.tvItemWeight);
            }
        }
    }
}